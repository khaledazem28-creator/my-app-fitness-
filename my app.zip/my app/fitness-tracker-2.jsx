import { useState, useEffect } from "react";

// ========== HELPERS ==========
const getLS = (key, def) => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch { return def; } };
const setLS = (key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} };
const uid = () => Math.random().toString(36).slice(2, 8);

const DAYS_ORDER = ["السبت","الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"];
const REST_DAYS_DEFAULT = ["الثلاثاء","الجمعة"];

const todayName = () => {
  const map = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
  return map[new Date().getDay()];
};

const DAY_COLORS = {
  السبت:"#e74c3c", الأحد:"#3498db", الاثنين:"#9b59b6",
  الثلاثاء:"#95a5a6", الأربعاء:"#27ae60", الخميس:"#e67e22", الجمعة:"#95a5a6"
};

// ========== DEFAULT DATA ==========
const DEFAULT_PROFILE = {
  name:"بطل", weight:90, height:185, goal:"تضخيم مع تنشيف",
  targetCalories:2800, targetProtein:180, targetCarbs:300, targetFat:80,
};

const DEFAULT_WORKOUT = {
  السبت:{ muscle:"صدر + ترايسبس", exercises:[
    { id:"1", name:"بنش بريس بار", sets:4, reps:"10-12", rest:"90 ث", notes:"ركز على اللف الكامل", weights:{} },
    { id:"2", name:"انكلاين دمبل بريس", sets:3, reps:"10-12", rest:"90 ث", notes:"زاوية 45 درجة", weights:{} },
    { id:"3", name:"بترفلاي ماكينة", sets:3, reps:"12-15", rest:"60 ث", notes:"احسس بالعضلة", weights:{} },
    { id:"4", name:"ترايسبس بوش داون", sets:3, reps:"12-15", rest:"60 ث", notes:"ثبت كوعك", weights:{} },
    { id:"5", name:"سكل كراشر", sets:3, reps:"10-12", rest:"60 ث", notes:"بطيء في النزول", weights:{} },
  ]},
  الأحد:{ muscle:"ظهر + بايسبس", exercises:[
    { id:"6", name:"لات بوش داون", sets:4, reps:"10-12", rest:"90 ث", notes:"اسحب للصدر", weights:{} },
    { id:"7", name:"روينج بار", sets:4, reps:"10-12", rest:"90 ث", notes:"ثبت الظهر", weights:{} },
    { id:"8", name:"كيبل روينج", sets:3, reps:"12-15", rest:"60 ث", notes:"اسحب للبطن", weights:{} },
    { id:"9", name:"كيرل بار", sets:3, reps:"10-12", rest:"60 ث", notes:"مكمل في الأعلى", weights:{} },
    { id:"10", name:"هامر كيرل", sets:3, reps:"12", rest:"60 ث", notes:"ببطء", weights:{} },
  ]},
  الاثنين:{ muscle:"أكتاف", exercises:[
    { id:"11", name:"شولدر بريس بار", sets:4, reps:"10-12", rest:"90 ث", notes:"لا تفرط في الانحناء", weights:{} },
    { id:"12", name:"لاتيرال ريز", sets:4, reps:"12-15", rest:"60 ث", notes:"مرفق بسيط", weights:{} },
    { id:"13", name:"فرونت ريز", sets:3, reps:"12", rest:"60 ث", notes:"تبادل الإيدين", weights:{} },
    { id:"14", name:"فيس بول", sets:3, reps:"15", rest:"60 ث", notes:"للكتف الخلفي", weights:{} },
    { id:"15", name:"شراق", sets:3, reps:"15", rest:"60 ث", notes:"للتراس", weights:{} },
  ]},
  الثلاثاء:{ muscle:"راحة 💤", exercises:[] },
  الأربعاء:{ muscle:"أرجل", exercises:[
    { id:"16", name:"سكوات بار", sets:4, reps:"10-12", rest:"120 ث", notes:"ظهر مستقيم", weights:{} },
    { id:"17", name:"ليج بريس", sets:4, reps:"12-15", rest:"90 ث", notes:"عميق", weights:{} },
    { id:"18", name:"ليج اكستنشن", sets:3, reps:"15", rest:"60 ث", notes:"للكواد", weights:{} },
    { id:"19", name:"ليج كيرل", sets:3, reps:"12-15", rest:"60 ث", notes:"للهامسترنج", weights:{} },
    { id:"20", name:"ستاندينج كاف ريز", sets:4, reps:"20", rest:"45 ث", notes:"تمام في الأعلى", weights:{} },
  ]},
  الخميس:{ muscle:"صدر + ترايسبس (B)", exercises:[
    { id:"21", name:"دمبل فلات بريس", sets:4, reps:"10-12", rest:"90 ث", notes:"تبديل الدمبل", weights:{} },
    { id:"22", name:"ديكلاين بريس", sets:3, reps:"10-12", rest:"90 ث", notes:"لأسفل الصدر", weights:{} },
    { id:"23", name:"كيبل فلاي", sets:3, reps:"15", rest:"60 ث", notes:"ابسط الذراعين", weights:{} },
    { id:"24", name:"ترايسبس ديبس", sets:3, reps:"12", rest:"60 ث", notes:"وزن جسمك", weights:{} },
    { id:"25", name:"اوفرهيد ترايسبس", sets:3, reps:"12", rest:"60 ث", notes:"كوع فوق الرأس", weights:{} },
  ]},
  الجمعة:{ muscle:"راحة 💤", exercises:[] },
};

// Generate meals from calorie target
function generateMeals(targetCal, targetPro, targetCarbs, targetFat) {
  const scale = targetCal / 2800;
  return [
    {
      id:"m1", name:"وجبة 1 - فطار (7 ص)",
      items:[
        { id:"i1", name:"بيض مسلوق أو مقلي", amount: Math.round(3*scale+1), unit:"حبة" },
        { id:"i2", name:"جبنة قريش", amount: Math.round(100*scale), unit:"جم" },
        { id:"i3", name:"توست أسمر", amount: Math.round(2*scale), unit:"شريحة" },
        { id:"i4", name:"موزة", amount:1, unit:"حبة" },
      ],
      calories: Math.round(650*scale), protein: Math.round(45*scale), carbs: Math.round(65*scale), fat: Math.round(20*scale)
    },
    {
      id:"m2", name:"وجبة 2 - سناك (10 ص)",
      items:[
        { id:"i5", name:"بيض مسلوق", amount: Math.round(2*scale), unit:"حبة" },
        { id:"i6", name:"فاكهة (تفاح أو برتقال)", amount:1, unit:"حبة" },
      ],
      calories: Math.round(220*scale), protein: Math.round(14*scale), carbs: Math.round(25*scale), fat: Math.round(10*scale)
    },
    {
      id:"m3", name:"وجبة 3 - غداء (1 ظ)",
      items:[
        { id:"i7", name:"وراك فراخ مشوي (بدون جلد)", amount: Math.round(300*scale), unit:"جم" },
        { id:"i8", name:"أرز أبيض أو بني", amount: Math.round(1.5*scale*100)/100, unit:"كوب" },
        { id:"i9", name:"سلطة خضرا", amount:1, unit:"طبق" },
      ],
      calories: Math.round(700*scale), protein: Math.round(60*scale), carbs: Math.round(80*scale), fat: Math.round(15*scale)
    },
    {
      id:"m4", name:"وجبة 4 - قبل التمرين (4 م)",
      items:[
        { id:"i10", name:"جبنة قريش", amount: Math.round(150*scale), unit:"جم" },
        { id:"i11", name:"موزة", amount:1, unit:"حبة" },
        { id:"i12", name:"عسل", amount:1, unit:"ملعقة" },
      ],
      calories: Math.round(350*scale), protein: Math.round(20*scale), carbs: Math.round(55*scale), fat: Math.round(5*scale)
    },
    {
      id:"m5", name:"وجبة 5 - بعد التمرين (7 م)",
      items:[
        { id:"i13", name:"وراك فراخ مشوي", amount: Math.round(250*scale), unit:"جم" },
        { id:"i14", name:"بيض كامل + بياض", amount: `${Math.round(2*scale)} كامل + ${Math.round(2*scale)} بياض`, unit:"" },
        { id:"i15", name:"أرز أو بطاطس مسلوقة", amount:1, unit:"كوب" },
      ],
      calories: Math.round(620*scale), protein: Math.round(55*scale), carbs: Math.round(60*scale), fat: Math.round(18*scale)
    },
    {
      id:"m6", name:"وجبة 6 - عشاء (10 م)",
      items:[
        { id:"i16", name:"جبنة قريش", amount: Math.round(200*scale), unit:"جم" },
        { id:"i17", name:"خيارة أو طماطمة", amount:1, unit:"حبة" },
        { id:"i18", name:"زيت زيتون", amount:1, unit:"ملعقة" },
      ],
      calories: Math.round(260*scale), protein: Math.round(24*scale), carbs: Math.round(12*scale), fat: Math.round(12*scale)
    },
  ];
}

// ========== SHARED UI ==========
function NavBar({ active, setActive }) {
  const tabs = [
    { id:"home", icon:"🏠", label:"الرئيسية" },
    { id:"workout", icon:"💪", label:"تمرين" },
    { id:"nutrition", icon:"🥗", label:"تغذية" },
    { id:"progress", icon:"📈", label:"تقدمي" },
    { id:"settings", icon:"⚙️", label:"الإعدادات" },
  ];
  return (
    <nav style={{ position:"fixed", bottom:0, left:0, right:0, background:"#111827", borderTop:"1px solid #1f2937", display:"flex", zIndex:100 }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => setActive(t.id)} style={{ flex:1, padding:"10px 4px 8px", background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3, color: active===t.id?"#00d084":"#6b7280" }}>
          <span style={{ fontSize:20 }}>{t.icon}</span>
          <span style={{ fontSize:10, fontFamily:"Cairo, sans-serif", fontWeight: active===t.id?700:400 }}>{t.label}</span>
        </button>
      ))}
    </nav>
  );
}

function MacroBar({ label, current, target, color }) {
  const pct = Math.min(100, target>0 ? Math.round((current/target)*100) : 0);
  return (
    <div style={{ marginBottom:12 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
        <span style={{ color:"#e5e7eb", fontFamily:"Cairo, sans-serif", fontSize:13 }}>{label}</span>
        <span style={{ color, fontFamily:"Cairo, sans-serif", fontSize:13, fontWeight:700 }}>{current} / {target}</span>
      </div>
      <div style={{ background:"#374151", borderRadius:99, height:7, overflow:"hidden" }}>
        <div style={{ background:color, width:`${pct}%`, height:"100%", borderRadius:99, transition:"width .4s" }} />
      </div>
    </div>
  );
}

function StatCard({ label, value, unit, color, icon }) {
  return (
    <div style={{ background:"#1f2937", borderRadius:16, padding:"14px 12px", flex:1, minWidth:0 }}>
      <div style={{ fontSize:20, marginBottom:5 }}>{icon}</div>
      <div style={{ color, fontSize:20, fontWeight:800, fontFamily:"Cairo, sans-serif" }}>{value}<span style={{ fontSize:11, fontWeight:400, color:"#9ca3af", marginRight:2 }}>{unit}</span></div>
      <div style={{ color:"#9ca3af", fontSize:11, fontFamily:"Cairo, sans-serif", marginTop:2 }}>{label}</div>
    </div>
  );
}

// ========== EXERCISE MODAL ==========
function ExerciseModal({ exercise, onSave, onClose }) {
  const [form, setForm] = useState(exercise ? { ...exercise } : { name:"", sets:3, reps:"10-12", rest:"60 ث", notes:"", weights:{} });
  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.75)", zIndex:200, display:"flex", alignItems:"flex-end" }} onClick={onClose}>
      <div style={{ background:"#1f2937", borderRadius:"20px 20px 0 0", padding:22, width:"100%", maxWidth:480, margin:"0 auto" }} onClick={e=>e.stopPropagation()}>
        <div style={{ color:"#fff", fontWeight:800, fontSize:17, marginBottom:16, fontFamily:"Cairo, sans-serif" }}>{exercise?"✏️ تعديل التمرين":"➕ تمرين جديد"}</div>
        {[{label:"اسم التمرين",key:"name",ph:"مثلاً: بنش بريس"},{label:"الرابطات",key:"reps",ph:"مثلاً: 10-12"},{label:"وقت الراحة",key:"rest",ph:"مثلاً: 90 ث"},{label:"ملاحظة",key:"notes",ph:"اختياري"}].map(f=>(
          <div key={f.key} style={{ marginBottom:12 }}>
            <div style={{ color:"#9ca3af", fontSize:12, fontFamily:"Cairo, sans-serif", marginBottom:5 }}>{f.label}</div>
            <input value={form[f.key]||""} onChange={e=>set(f.key,e.target.value)} placeholder={f.ph}
              style={{ width:"100%", background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none", boxSizing:"border-box" }} />
          </div>
        ))}
        <div style={{ marginBottom:16 }}>
          <div style={{ color:"#9ca3af", fontSize:12, fontFamily:"Cairo, sans-serif", marginBottom:5 }}>عدد السيتات</div>
          <div style={{ display:"flex", gap:8 }}>
            {[2,3,4,5,6].map(n=>(
              <button key={n} onClick={()=>set("sets",n)} style={{ flex:1, padding:"10px 0", background:form.sets===n?"#00d084":"#374151", color:form.sets===n?"#064e3b":"#9ca3af", border:"none", borderRadius:10, fontFamily:"Cairo, sans-serif", fontWeight:700, cursor:"pointer", fontSize:15 }}>{n}</button>
            ))}
          </div>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onClose} style={{ flex:1, padding:13, background:"#374151", color:"#9ca3af", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:700, cursor:"pointer" }}>إلغاء</button>
          <button onClick={()=>{ if(form.name.trim()) onSave({...form, id:form.id||uid()}); }} style={{ flex:2, padding:13, background:"#00d084", color:"#064e3b", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer", fontSize:15 }}>حفظ ✓</button>
        </div>
      </div>
    </div>
  );
}

// ========== MEAL ITEM EDITOR ==========
function MealItemModal({ item, onSave, onClose }) {
  const [form, setForm] = useState({ ...item });
  const s = (k,v) => setForm(f=>({...f,[k]:v}));
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.75)", zIndex:200, display:"flex", alignItems:"flex-end" }} onClick={onClose}>
      <div style={{ background:"#1f2937", borderRadius:"20px 20px 0 0", padding:22, width:"100%", maxWidth:480, margin:"0 auto" }} onClick={e=>e.stopPropagation()}>
        <div style={{ color:"#fff", fontWeight:800, fontSize:17, marginBottom:16, fontFamily:"Cairo, sans-serif" }}>✏️ تعديل الأكلة</div>
        {[{label:"اسم الأكلة",key:"name",ph:"مثلاً: بيض مسلوق"},{label:"الكمية",key:"amount",ph:"مثلاً: 3"},{label:"الوحدة",key:"unit",ph:"مثلاً: حبة / جم / كوب"}].map(f=>(
          <div key={f.key} style={{ marginBottom:12 }}>
            <div style={{ color:"#9ca3af", fontSize:12, fontFamily:"Cairo, sans-serif", marginBottom:5 }}>{f.label}</div>
            <input value={form[f.key]||""} onChange={e=>s(f.key,e.target.value)} placeholder={f.ph}
              style={{ width:"100%", background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none", boxSizing:"border-box" }} />
          </div>
        ))}
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onClose} style={{ flex:1, padding:13, background:"#374151", color:"#9ca3af", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:700, cursor:"pointer" }}>إلغاء</button>
          <button onClick={()=>{ if(form.name.trim()) onSave(form); }} style={{ flex:2, padding:13, background:"#00d084", color:"#064e3b", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer" }}>حفظ ✓</button>
        </div>
      </div>
    </div>
  );
}

// ========== HOME ==========
function HomePage({ profile, workoutPlan, nutrition }) {
  const today = todayName();
  const plan = workoutPlan[today];
  const todayNut = nutrition[new Date().toDateString()] || { cal:0, pro:0, carbs:0, fat:0 };
  const bmi = (profile.weight/((profile.height/100)**2)).toFixed(1);

  return (
    <div style={{ padding:"24px 16px 100px", fontFamily:"Cairo, sans-serif" }}>
      <div style={{ marginBottom:22 }}>
        <div style={{ color:"#9ca3af", fontSize:13 }}>أهلاً بك 💚</div>
        <div style={{ color:"#fff", fontSize:25, fontWeight:800 }}>داشبورد البطل</div>
        <div style={{ color:"#00d084", fontSize:13, marginTop:3 }}>{today} — {plan.muscle}</div>
      </div>

      <div style={{ display:"flex", gap:8, marginBottom:14 }}>
        <StatCard label="الوزن" value={profile.weight} unit="كجم" color="#00d084" icon="⚖️" />
        <StatCard label="الطول" value={profile.height} unit="سم" color="#3b82f6" icon="📏" />
        <StatCard label="BMI" value={bmi} unit="" color="#a78bfa" icon="💡" />
      </div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:16, marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
          <span style={{ color:"#fff", fontWeight:700 }}>تمرين النهارده</span>
          <span style={{ background: DAY_COLORS[today], color:"#fff", borderRadius:99, padding:"3px 11px", fontSize:12, fontWeight:700 }}>{plan.muscle}</span>
        </div>
        {plan.exercises.length===0
          ? <div style={{ color:"#6b7280", textAlign:"center", padding:"16px 0" }}>يوم راحة 💤</div>
          : plan.exercises.slice(0,3).map(ex=>(
              <div key={ex.id} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:"1px solid #374151" }}>
                <span style={{ color:"#e5e7eb", fontSize:14 }}>{ex.name}</span>
                <span style={{ color:"#9ca3af", fontSize:13 }}>{ex.sets}×{ex.reps}</span>
              </div>
            ))
        }
        {plan.exercises.length>3 && <div style={{ color:"#00d084", fontSize:13, marginTop:8, textAlign:"center" }}>+ {plan.exercises.length-3} تمرين تاني</div>}
      </div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:16, marginBottom:14 }}>
        <div style={{ color:"#fff", fontWeight:700, marginBottom:12 }}>سعرات النهارده</div>
        <MacroBar label="سعرات" current={todayNut.cal} target={profile.targetCalories} color="#f59e0b" />
        <MacroBar label="بروتين جم" current={todayNut.pro} target={profile.targetProtein} color="#3b82f6" />
        <MacroBar label="كارب جم" current={todayNut.carbs} target={profile.targetCarbs} color="#a78bfa" />
        <MacroBar label="دهون جم" current={todayNut.fat} target={profile.targetFat} color="#f87171" />
      </div>

      <div style={{ background:"linear-gradient(135deg,#064e3b,#065f46)", borderRadius:18, padding:16, border:"1px solid #059669" }}>
        <div style={{ color:"#6ee7b7", fontWeight:700, marginBottom:6 }}>💡 نصيحة اليوم</div>
        <div style={{ color:"#a7f3d0", fontSize:13, lineHeight:1.7 }}>
          هدفك {profile.goal}. ركز على التدرج في الأوزان كل أسبوع وسجل وزن كل تمرينة. {profile.targetProtein}جم بروتين يوميًا هو مفتاحك!
        </div>
      </div>
    </div>
  );
}

// ========== WORKOUT ==========
function WorkoutPage({ workoutPlan, setWorkoutPlan }) {
  const [selectedDay, setSelectedDay] = useState(todayName());
  const [done, setDone] = useState(getLS("done_exercises",{}));
  const [modal, setModal] = useState(null);
  const [weightModal, setWeightModal] = useState(null); // { exercise }
  const [weekInput, setWeekInput] = useState("");
  const [weightVal, setWeightVal] = useState("");

  const plan = workoutPlan[selectedDay];
  const isRest = REST_DAYS_DEFAULT.includes(selectedDay) || plan.exercises.length===0;

  const toggleDone = (exId) => {
    const key = `${selectedDay}_${exId}`;
    const u = {...done,[key]:!done[key]};
    setDone(u); setLS("done_exercises",u);
  };

  const saveEx = (ex) => {
    const exs = plan.exercises;
    const updated = modal.mode==="edit" ? exs.map(e=>e.id===ex.id?ex:e) : [...exs,ex];
    const np = {...workoutPlan,[selectedDay]:{...plan,exercises:updated}};
    setWorkoutPlan(np); setLS("workout_plan",np); setModal(null);
  };

  const deleteEx = (exId) => {
    const updated = plan.exercises.filter(e=>e.id!==exId);
    const np = {...workoutPlan,[selectedDay]:{...plan,exercises:updated}};
    setWorkoutPlan(np); setLS("workout_plan",np);
  };

  const saveWeight = () => {
    const w = parseFloat(weightVal);
    const wk = weekInput.trim();
    if (!wk || isNaN(w)) return;
    const ex = weightModal.exercise;
    const updatedEx = {...ex, weights:{...ex.weights,[wk]:w}};
    const exs = plan.exercises.map(e=>e.id===ex.id?updatedEx:e);
    const np = {...workoutPlan,[selectedDay]:{...plan,exercises:exs}};
    setWorkoutPlan(np); setLS("workout_plan",np);
    setWeightModal(null); setWeekInput(""); setWeightVal("");
  };

  const doneCount = plan.exercises.filter(ex=>done[`${selectedDay}_${ex.id}`]).length;

  return (
    <div style={{ padding:"24px 16px 100px", fontFamily:"Cairo, sans-serif" }}>
      <div style={{ color:"#fff", fontSize:22, fontWeight:800, marginBottom:16 }}>برنامج التمرين 💪</div>

      <div style={{ display:"flex", gap:7, overflowX:"auto", marginBottom:18, paddingBottom:4 }}>
        {DAYS_ORDER.map(day=>(
          <button key={day} onClick={()=>setSelectedDay(day)} style={{
            background: selectedDay===day ? DAY_COLORS[day]:"#1f2937",
            color:"#fff", border:"none", borderRadius:99, padding:"7px 13px",
            fontSize:12, fontFamily:"Cairo, sans-serif", cursor:"pointer", whiteSpace:"nowrap",
            fontWeight:selectedDay===day?700:400, opacity:REST_DAYS_DEFAULT.includes(day)?.7:1
          }}>{day}{REST_DAYS_DEFAULT.includes(day)?" 💤":""}</button>
        ))}
      </div>

      <div style={{ background:"#1f2937", borderRadius:18, overflow:"hidden" }}>
        <div style={{ background: DAY_COLORS[selectedDay], padding:"14px 16px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ color:"#fff", fontWeight:800, fontSize:17 }}>{selectedDay}</div>
            <div style={{ color:"rgba(255,255,255,.8)", fontSize:13 }}>{plan.muscle}</div>
          </div>
          {!REST_DAYS_DEFAULT.includes(selectedDay) && (
            <button onClick={()=>setModal({mode:"add"})} style={{ background:"rgba(255,255,255,.2)", color:"#fff", border:"none", borderRadius:99, padding:"7px 14px", fontFamily:"Cairo, sans-serif", fontWeight:700, cursor:"pointer", fontSize:13 }}>+ تمرين</button>
          )}
        </div>

        {REST_DAYS_DEFAULT.includes(selectedDay) ? (
          <div style={{ padding:36, textAlign:"center" }}>
            <div style={{ fontSize:44 }}>💤</div>
            <div style={{ color:"#9ca3af", marginTop:10 }}>يوم راحة — جسمك بيكبر وهو بيرتاح!</div>
          </div>
        ) : plan.exercises.length===0 ? (
          <div style={{ padding:36, textAlign:"center" }}>
            <div style={{ fontSize:44 }}>🏋️</div>
            <div style={{ color:"#6b7280", marginBottom:14, marginTop:10 }}>مفيش تمارين لسه</div>
            <button onClick={()=>setModal({mode:"add"})} style={{ background:"#00d084", color:"#064e3b", border:"none", borderRadius:12, padding:"11px 22px", fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer" }}>+ أضف أول تمرين</button>
          </div>
        ) : (
          <>
            {plan.exercises.map((ex,i)=>{
              const key=`${selectedDay}_${ex.id}`;
              const isDone=done[key];
              const weekKeys = Object.keys(ex.weights||{}).sort();
              const lastWeek = weekKeys.length>0 ? weekKeys[weekKeys.length-1] : null;
              const lastWt = lastWeek ? ex.weights[lastWeek] : null;
              return (
                <div key={ex.id} style={{ borderBottom: i<plan.exercises.length-1?"1px solid #374151":"none" }}>
                  {/* Main row */}
                  <div style={{ display:"flex", alignItems:"center", gap:10, padding:"12px 14px", background:isDone?"rgba(0,208,132,.06)":"transparent" }}>
                    <div onClick={()=>toggleDone(ex.id)} style={{ width:26, height:26, borderRadius:99, background:isDone?"#00d084":"#374151", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:13, cursor:"pointer" }}>
                      {isDone?"✓":i+1}
                    </div>
                    <div style={{ flex:1, minWidth:0 }} onClick={()=>toggleDone(ex.id)}>
                      <div style={{ color:isDone?"#6ee7b7":"#e5e7eb", fontWeight:600, fontSize:14, textDecoration:isDone?"line-through":"none" }}>{ex.name}</div>
                      <div style={{ color:"#9ca3af", fontSize:12, marginTop:2 }}>{ex.sets} سيت × {ex.reps} — {ex.rest}</div>
                      {lastWt && <div style={{ color:"#f59e0b", fontSize:11, marginTop:2 }}>آخر وزن: {lastWt} كجم ({lastWeek})</div>}
                    </div>
                    <div style={{ display:"flex", gap:5, flexShrink:0 }}>
                      <button onClick={()=>setWeightModal({exercise:ex})} style={{ background:"#1c3a5e", color:"#60a5fa", border:"none", borderRadius:8, width:28, height:28, cursor:"pointer", fontSize:13 }}>⚖️</button>
                      <button onClick={()=>setModal({mode:"edit",exercise:ex})} style={{ background:"#374151", color:"#9ca3af", border:"none", borderRadius:8, width:28, height:28, cursor:"pointer", fontSize:13 }}>✏️</button>
                      <button onClick={()=>deleteEx(ex.id)} style={{ background:"#3f1a1a", color:"#f87171", border:"none", borderRadius:8, width:28, height:28, cursor:"pointer", fontSize:13 }}>🗑</button>
                    </div>
                  </div>

                  {/* Weight history table */}
                  {weekKeys.length>0 && (
                    <div style={{ background:"#161f2e", padding:"10px 14px 12px", overflowX:"auto" }}>
                      <div style={{ color:"#60a5fa", fontSize:12, fontWeight:700, marginBottom:8 }}>📊 جدول الأوزان</div>
                      <table style={{ width:"100%", borderCollapse:"collapse", minWidth: weekKeys.length>3?`${weekKeys.length*80}px`:"auto" }}>
                        <thead>
                          <tr>
                            {weekKeys.map(wk=>(
                              <th key={wk} style={{ color:"#9ca3af", fontSize:11, padding:"4px 8px", textAlign:"center", whiteSpace:"nowrap", borderBottom:"1px solid #374151" }}>{wk}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            {weekKeys.map((wk,wi)=>{
                              const prev = wi>0 ? ex.weights[weekKeys[wi-1]] : null;
                              const curr = ex.weights[wk];
                              const up = prev && curr>prev;
                              return (
                                <td key={wk} style={{ color: up?"#00d084":"#e5e7eb", fontSize:13, fontWeight:700, padding:"5px 8px", textAlign:"center" }}>
                                  {curr} كجم {up?"↑":""}
                                </td>
                              );
                            })}
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
            <div style={{ padding:"11px 16px", background:"#111827" }}>
              <span style={{ color:"#9ca3af", fontSize:12 }}>{doneCount}/{plan.exercises.length} تمارين ✓ {doneCount===plan.exercises.length&&plan.exercises.length>0?"🔥 خلصت كلها!":""}</span>
            </div>
          </>
        )}
      </div>

      {/* Exercise modal */}
      {modal && <ExerciseModal exercise={modal.mode==="edit"?modal.exercise:null} onSave={saveEx} onClose={()=>setModal(null)} />}

      {/* Weight logging modal */}
      {weightModal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.75)", zIndex:200, display:"flex", alignItems:"flex-end" }} onClick={()=>setWeightModal(null)}>
          <div style={{ background:"#1f2937", borderRadius:"20px 20px 0 0", padding:22, width:"100%", maxWidth:480, margin:"0 auto" }} onClick={e=>e.stopPropagation()}>
            <div style={{ color:"#fff", fontWeight:800, fontSize:17, marginBottom:4, fontFamily:"Cairo, sans-serif" }}>⚖️ سجل الوزن</div>
            <div style={{ color:"#9ca3af", fontSize:13, marginBottom:16, fontFamily:"Cairo, sans-serif" }}>{weightModal.exercise.name}</div>
            <div style={{ marginBottom:12 }}>
              <div style={{ color:"#9ca3af", fontSize:12, fontFamily:"Cairo, sans-serif", marginBottom:5 }}>الأسبوع (مثلاً: أسبوع 1)</div>
              <input value={weekInput} onChange={e=>setWeekInput(e.target.value)} placeholder="أسبوع 1"
                style={{ width:"100%", background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none", boxSizing:"border-box" }} />
            </div>
            <div style={{ marginBottom:18 }}>
              <div style={{ color:"#9ca3af", fontSize:12, fontFamily:"Cairo, sans-serif", marginBottom:5 }}>الوزن (كجم)</div>
              <input type="number" value={weightVal} onChange={e=>setWeightVal(e.target.value)} placeholder="مثلاً: 60"
                style={{ width:"100%", background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none", boxSizing:"border-box" }} />
            </div>
            {/* Existing weights */}
            {Object.keys(weightModal.exercise.weights||{}).length>0 && (
              <div style={{ background:"#111827", borderRadius:12, padding:12, marginBottom:16 }}>
                <div style={{ color:"#60a5fa", fontSize:12, fontWeight:700, marginBottom:8, fontFamily:"Cairo, sans-serif" }}>السجل الحالي</div>
                {Object.entries(weightModal.exercise.weights).sort().map(([wk,wt])=>(
                  <div key={wk} style={{ display:"flex", justifyContent:"space-between", padding:"4px 0" }}>
                    <span style={{ color:"#9ca3af", fontSize:13, fontFamily:"Cairo, sans-serif" }}>{wk}</span>
                    <span style={{ color:"#00d084", fontSize:13, fontWeight:700, fontFamily:"Cairo, sans-serif" }}>{wt} كجم</span>
                  </div>
                ))}
              </div>
            )}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setWeightModal(null)} style={{ flex:1, padding:13, background:"#374151", color:"#9ca3af", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:700, cursor:"pointer" }}>إلغاء</button>
              <button onClick={saveWeight} style={{ flex:2, padding:13, background:"#00d084", color:"#064e3b", border:"none", borderRadius:12, fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer" }}>حفظ ✓</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== NUTRITION ==========
function NutritionPage({ profile, meals, setMeals, nutrition, setNutrition }) {
  const todayKey = new Date().toDateString();
  const todayData = nutrition[todayKey] || { cal:0, pro:0, carbs:0, fat:0, checked:{} };
  const [editMeal, setEditMeal] = useState(null); // { mealIdx, itemIdx }
  const [itemModal, setItemModal] = useState(null);
  const [newItemMealIdx, setNewItemMealIdx] = useState(null);

  const recalcTotals = (meals, checked) => {
    let cal=0,pro=0,carbs=0,fat=0;
    meals.forEach((meal,mi)=>{
      if(checked[meal.id]) { cal+=meal.calories; pro+=meal.protein; carbs+=meal.carbs; fat+=meal.fat; }
    });
    return {cal,pro,carbs,fat};
  };

  const toggleMeal = (mealId) => {
    const checked = {...(todayData.checked||{}),[mealId]:!(todayData.checked||{})[mealId]};
    const totals = recalcTotals(meals,checked);
    const nd = {...nutrition,[todayKey]:{...totals,checked}};
    setNutrition(nd); setLS("nutrition",nd);
  };

  const saveMealItem = (item) => {
    const { mealIdx, itemIdx } = itemModal;
    const nm = meals.map((m,mi)=>{
      if(mi!==mealIdx) return m;
      const items = itemIdx===-1 ? [...m.items,{...item,id:uid()}] : m.items.map((it,ii)=>ii===itemIdx?item:it);
      return {...m,items};
    });
    setMeals(nm); setLS("meals",nm); setItemModal(null);
  };

  const deleteMealItem = (mealIdx, itemIdx) => {
    const nm = meals.map((m,mi)=>mi!==mealIdx?m:{...m,items:m.items.filter((_,ii)=>ii!==itemIdx)});
    setMeals(nm); setLS("meals",nm);
  };

  return (
    <div style={{ padding:"24px 16px 100px", fontFamily:"Cairo, sans-serif" }}>
      <div style={{ color:"#fff", fontSize:22, fontWeight:800, marginBottom:4 }}>النظام الغذائي 🥗</div>
      <div style={{ color:"#6b7280", fontSize:13, marginBottom:18 }}>هدف {profile.targetCalories} سعر يومياً</div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:16, marginBottom:14 }}>
        <div style={{ color:"#fff", fontWeight:700, marginBottom:12 }}>ملخص النهارده</div>
        <MacroBar label={`سعرات ${todayData.cal}/${profile.targetCalories}`} current={todayData.cal} target={profile.targetCalories} color="#f59e0b" />
        <MacroBar label={`بروتين ${todayData.pro}/${profile.targetProtein}جم`} current={todayData.pro} target={profile.targetProtein} color="#3b82f6" />
        <MacroBar label={`كارب ${todayData.carbs}/${profile.targetCarbs}جم`} current={todayData.carbs} target={profile.targetCarbs} color="#a78bfa" />
        <MacroBar label={`دهون ${todayData.fat}/${profile.targetFat}جم`} current={todayData.fat} target={profile.targetFat} color="#f87171" />
      </div>

      {meals.map((meal,mealIdx)=>{
        const checked=(todayData.checked||{})[meal.id];
        return (
          <div key={meal.id} style={{ background:"#1f2937", borderRadius:16, padding:14, marginBottom:12, border:checked?"1.5px solid #00d084":"1.5px solid transparent" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
              <div>
                <div style={{ color:checked?"#6ee7b7":"#e5e7eb", fontWeight:700, fontSize:14 }}>{meal.name}</div>
                <div style={{ color:"#9ca3af", fontSize:12, marginTop:2 }}>{meal.calories} سعر — {meal.protein}جم بروتين</div>
              </div>
              <button onClick={()=>toggleMeal(meal.id)} style={{ background:checked?"#00d084":"#374151", color:checked?"#064e3b":"#9ca3af", border:"none", borderRadius:99, width:34, height:34, cursor:"pointer", fontSize:16, fontWeight:700, flexShrink:0 }}>{checked?"✓":"+"}</button>
            </div>
            {/* Items */}
            {meal.items.map((item,itemIdx)=>(
              <div key={item.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"5px 0", borderTop:"1px solid #374151" }}>
                <span style={{ color:"#9ca3af", fontSize:13 }}>{item.amount}{item.unit?" "+item.unit:""} {item.name}</span>
                <div style={{ display:"flex", gap:5 }}>
                  <button onClick={()=>setItemModal({mealIdx,itemIdx,item})} style={{ background:"none", border:"none", color:"#6b7280", cursor:"pointer", fontSize:13 }}>✏️</button>
                  <button onClick={()=>deleteMealItem(mealIdx,itemIdx)} style={{ background:"none", border:"none", color:"#6b7280", cursor:"pointer", fontSize:13 }}>🗑</button>
                </div>
              </div>
            ))}
            <button onClick={()=>setItemModal({mealIdx,itemIdx:-1,item:{id:"",name:"",amount:"",unit:""}})} style={{ marginTop:8, background:"#374151", color:"#9ca3af", border:"none", borderRadius:8, padding:"5px 12px", fontFamily:"Cairo, sans-serif", fontSize:12, cursor:"pointer" }}>+ أضف أكلة</button>
          </div>
        );
      })}

      {itemModal && <MealItemModal item={itemModal.item} onSave={saveMealItem} onClose={()=>setItemModal(null)} />}
    </div>
  );
}

// ========== PROGRESS ==========
function ProgressPage({ profile, weights, setWeights }) {
  const [newWeight, setNewWeight] = useState("");
  const startW = weights.length>0?weights[0].weight:profile.weight;
  const currentW = weights.length>0?weights[weights.length-1].weight:profile.weight;
  const diff = (currentW-startW).toFixed(1);
  const bmi = (currentW/((profile.height/100)**2)).toFixed(1);

  const addWeight = () => {
    const w = parseFloat(newWeight);
    if(isNaN(w)||w<40||w>250) return;
    const entry={weight:w,date:new Date().toLocaleDateString("ar-EG",{day:"numeric",month:"short"}),ts:Date.now()};
    const u=[...weights,entry]; setWeights(u); setLS("weights",u); setNewWeight("");
  };

  return (
    <div style={{ padding:"24px 16px 100px", fontFamily:"Cairo, sans-serif" }}>
      <div style={{ color:"#fff", fontSize:22, fontWeight:800, marginBottom:18 }}>تقدمي 📈</div>

      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        <StatCard label="الوزن الأول" value={startW} unit="كجم" color="#9ca3af" icon="🏁" />
        <StatCard label="الحالي" value={currentW} unit="كجم" color="#00d084" icon="⚖️" />
        <StatCard label="الفرق" value={Number(diff)>0?`+${diff}`:diff} unit="كجم" color={Number(diff)>=0?"#3b82f6":"#f59e0b"} icon="📊" />
      </div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:16, marginBottom:14 }}>
        <div style={{ color:"#fff", fontWeight:700, marginBottom:10 }}>سجل وزن جديد</div>
        <div style={{ display:"flex", gap:10 }}>
          <input type="number" value={newWeight} onChange={e=>setNewWeight(e.target.value)} placeholder="الوزن كجم"
            style={{ flex:1, background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none" }} />
          <button onClick={addWeight} style={{ background:"#00d084", color:"#064e3b", border:"none", borderRadius:10, padding:"11px 18px", fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer" }}>+ أضف</button>
        </div>
        <div style={{ color:"#6b7280", fontSize:12, marginTop:7 }}>سجل كل أسبوع الصبح قبل الأكل</div>
      </div>

      {weights.length>=2 && (
        <div style={{ background:"#1f2937", borderRadius:18, padding:16, marginBottom:14 }}>
          <div style={{ color:"#fff", fontWeight:700, marginBottom:12 }}>رحلة الوزن</div>
          <div style={{ overflowX:"auto" }}>
            <svg height="130" style={{ minWidth: Math.max(300,weights.length*50), width:"100%" }} viewBox={`0 0 ${Math.max(300,weights.length*50)} 130`} preserveAspectRatio="none">
              {(()=>{
                const ws=weights.map(w=>w.weight),mn=Math.min(...ws)-1,mx=Math.max(...ws)+1;
                const W=Math.max(300,weights.length*50);
                const pts=weights.map((w,i)=>{const x=(i/(weights.length-1))*(W-40)+20,y=110-((w.weight-mn)/(mx-mn))*90;return `${x},${y}`;}).join(" ");
                return <>
                  <polyline points={pts} fill="none" stroke="#00d084" strokeWidth="2.5" strokeLinejoin="round"/>
                  {weights.map((w,i)=>{
                    const x=(i/(weights.length-1))*(W-40)+20,y=110-((w.weight-mn)/(mx-mn))*90;
                    return <g key={i}><circle cx={x} cy={y} r="4" fill="#00d084"/><text x={x} y={y-8} textAnchor="middle" fill="#9ca3af" fontSize="10">{w.weight}</text></g>;
                  })}
                </>;
              })()}
            </svg>
          </div>
        </div>
      )}

      {weights.length>0 && (
        <div style={{ background:"#1f2937", borderRadius:18, overflow:"hidden", marginBottom:14 }}>
          <div style={{ padding:"12px 16px", borderBottom:"1px solid #374151", display:"flex", justifyContent:"space-between" }}>
            <span style={{ color:"#9ca3af", fontSize:12 }}>التاريخ</span>
            <span style={{ color:"#9ca3af", fontSize:12 }}>الوزن</span>
            <span style={{ color:"#9ca3af", fontSize:12 }}>التغيير</span>
          </div>
          {[...weights].reverse().map((w,i,arr)=>{
            const prev=arr[i+1];
            const change=prev?(w.weight-prev.weight).toFixed(1):null;
            return (
              <div key={w.ts} style={{ display:"flex", justifyContent:"space-between", padding:"12px 16px", borderBottom:i<arr.length-1?"1px solid #374151":"none" }}>
                <span style={{ color:"#9ca3af", fontSize:14 }}>{w.date}</span>
                <span style={{ color:"#fff", fontWeight:700 }}>{w.weight} كجم</span>
                <span style={{ color:change===null?"#6b7280":Number(change)>0?"#3b82f6":"#f59e0b", fontWeight:700 }}>{change===null?"—":Number(change)>0?`+${change}`:change}</span>
              </div>
            );
          })}
        </div>
      )}

      <div style={{ background:"linear-gradient(135deg,#1e3a5f,#1e40af)", borderRadius:18, padding:16 }}>
        <div style={{ color:"#93c5fd", fontWeight:700, marginBottom:6 }}>🏆 هدفك</div>
        <div style={{ color:"#dbeafe", fontSize:13, lineHeight:1.7 }}>استمر 3 أشهر على البرنامج وهتشوف فرق واضح. التدرج في الأوزان هو مفتاح التضخيم!</div>
      </div>
    </div>
  );
}

// ========== SETTINGS ==========
function SettingsPage({ profile, setProfile, meals, setMeals }) {
  const [form, setForm] = useState({...profile});
  const [saved, setSaved] = useState(false);
  const s = (k,v) => setForm(f=>({...f,[k]:v}));

  const save = () => {
    // Regenerate meals based on new calories
    const newMeals = generateMeals(form.targetCalories, form.targetProtein, form.targetCarbs, form.targetFat);
    setProfile(form); setLS("profile",form);
    setMeals(newMeals); setLS("meals",newMeals);
    setSaved(true); setTimeout(()=>setSaved(false),2000);
  };

  return (
    <div style={{ padding:"24px 16px 100px", fontFamily:"Cairo, sans-serif" }}>
      <div style={{ color:"#fff", fontSize:22, fontWeight:800, marginBottom:18 }}>الإعدادات ⚙️</div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:18, marginBottom:14 }}>
        <div style={{ color:"#00d084", fontWeight:700, marginBottom:14, fontSize:15 }}>👤 بياناتك الشخصية</div>
        {[
          {label:"الاسم",key:"name",type:"text",ph:"اسمك"},
          {label:"الوزن الحالي (كجم)",key:"weight",type:"number",ph:"مثلاً: 90"},
          {label:"الطول (سم)",key:"height",type:"number",ph:"مثلاً: 185"},
        ].map(f=>(
          <div key={f.key} style={{ marginBottom:13 }}>
            <div style={{ color:"#9ca3af", fontSize:12, marginBottom:5 }}>{f.label}</div>
            <input type={f.type} value={form[f.key]||""} onChange={e=>s(f.key,f.type==="number"?Number(e.target.value):e.target.value)} placeholder={f.ph}
              style={{ width:"100%", background:"#374151", border:"none", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:15, fontFamily:"Cairo, sans-serif", outline:"none", boxSizing:"border-box" }} />
          </div>
        ))}
        <div style={{ marginBottom:13 }}>
          <div style={{ color:"#9ca3af", fontSize:12, marginBottom:5 }}>هدفك</div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            {["تضخيم مع تنشيف","تضخيم","تنشيف","حفاظ على الوزن"].map(g=>(
              <button key={g} onClick={()=>s("goal",g)} style={{ padding:"8px 14px", background:form.goal===g?"#00d084":"#374151", color:form.goal===g?"#064e3b":"#9ca3af", border:"none", borderRadius:10, fontFamily:"Cairo, sans-serif", fontWeight:form.goal===g?700:400, cursor:"pointer", fontSize:13 }}>{g}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ background:"#1f2937", borderRadius:18, padding:18, marginBottom:14 }}>
        <div style={{ color:"#f59e0b", fontWeight:700, marginBottom:6, fontSize:15 }}>🔥 هدف السعرات اليومية</div>
        <div style={{ color:"#9ca3af", fontSize:12, marginBottom:14, lineHeight:1.6 }}>
          لما تغير السعرات، نظام الأكل هيتعدل تلقائياً على حسبها
        </div>
        {[
          {label:"السعرات الكلية",key:"targetCalories",color:"#f59e0b"},
          {label:"البروتين (جم)",key:"targetProtein",color:"#3b82f6"},
          {label:"الكارب (جم)",key:"targetCarbs",color:"#a78bfa"},
          {label:"الدهون (جم)",key:"targetFat",color:"#f87171"},
        ].map(f=>(
          <div key={f.key} style={{ marginBottom:13 }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
              <span style={{ color:"#9ca3af", fontSize:12 }}>{f.label}</span>
              <span style={{ color:f.color, fontWeight:700, fontSize:14 }}>{form[f.key]}</span>
            </div>
            <input type="range" min={f.key==="targetCalories"?1500:50} max={f.key==="targetCalories"?5000:400} step={f.key==="targetCalories"?50:5}
              value={form[f.key]} onChange={e=>s(f.key,Number(e.target.value))}
              style={{ width:"100%", accentColor:f.color }} />
            <div style={{ display:"flex", justifyContent:"space-between" }}>
              <span style={{ color:"#6b7280", fontSize:11 }}>{f.key==="targetCalories"?"1500":"50"}</span>
              <span style={{ color:"#6b7280", fontSize:11 }}>{f.key==="targetCalories"?"5000":"400"}</span>
            </div>
          </div>
        ))}
      </div>

      <button onClick={save} style={{ width:"100%", padding:16, background: saved?"#059669":"#00d084", color:"#064e3b", border:"none", borderRadius:14, fontFamily:"Cairo, sans-serif", fontWeight:800, cursor:"pointer", fontSize:17, transition:"background .3s" }}>
        {saved?"✓ اتحفظ!":"💾 حفظ التعديلات"}
      </button>
      {saved && <div style={{ color:"#6ee7b7", textAlign:"center", marginTop:10, fontSize:13 }}>نظام الأكل اتغير على حسب السعرات الجديدة ✓</div>}
    </div>
  );
}

// ========== MAIN ==========
export default function App() {
  const [active, setActive] = useState("home");
  const [profile, setProfile] = useState(getLS("profile", DEFAULT_PROFILE));
  const [workoutPlan, setWorkoutPlan] = useState(getLS("workout_plan", DEFAULT_WORKOUT));
  const [meals, setMeals] = useState(getLS("meals", generateMeals(DEFAULT_PROFILE.targetCalories, DEFAULT_PROFILE.targetProtein, DEFAULT_PROFILE.targetCarbs, DEFAULT_PROFILE.targetFat)));
  const [nutrition, setNutrition] = useState(getLS("nutrition", {}));
  const [weights, setWeights] = useState(getLS("weights", [{ weight:90, date:"بداية", ts:Date.now()-86400000 }]));

  return (
    <div style={{ background:"#111827", minHeight:"100vh", maxWidth:480, margin:"0 auto", direction:"rtl", position:"relative" }}>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet" />
      {active==="home" && <HomePage profile={profile} workoutPlan={workoutPlan} nutrition={nutrition} />}
      {active==="workout" && <WorkoutPage workoutPlan={workoutPlan} setWorkoutPlan={setWorkoutPlan} />}
      {active==="nutrition" && <NutritionPage profile={profile} meals={meals} setMeals={setMeals} nutrition={nutrition} setNutrition={setNutrition} />}
      {active==="progress" && <ProgressPage profile={profile} weights={weights} setWeights={setWeights} />}
      {active==="settings" && <SettingsPage profile={profile} setProfile={setProfile} meals={meals} setMeals={setMeals} />}
      <NavBar active={active} setActive={setActive} />
    </div>
  );
}
